# devcoach — Coaching Notebook
_Last updated: 2026-04-28T12:00:00Z_

## Observations
Full-stack developer with a JavaScript-first background who moved to TypeScript
incrementally — knows the syntax but hasn't fully internalised the type system's
expressiveness (generics, conditional types, mapped types). Confident with Node.js
runtime internals and comfortable in the terminal. Tends to reach for familiar
patterns (REST, Express-style middleware) rather than exploring alternatives.

Security awareness exists at the conceptual level but hasn't translated into
habitual defensive coding — tends to handle happy paths first and add validation
later. Has good architectural instincts at the service level (knows when to split
responsibilities) but less comfortable reasoning about data access patterns and
query performance. PostgreSQL is used daily but mostly at the ORM level; raw SQL
and index design are gaps.

Docker and DevOps tooling are strengths — CI/CD is understood but not deeply
optimised. Testing confidence is stated as 5 but observed behaviour suggests it
is lower in practice: tends to write tests after the fact, often skips edge cases,
and hasn't adopted a consistent assertion strategy.

## Recurring patterns
- Reaches for `any` in TypeScript under time pressure — worth nudging toward
  `unknown` and type narrowing instead
- Tends to conflate caching strategies (TTL-only) without considering invalidation
  or stampede scenarios
- Git usage is solid day-to-day but commit granularity is coarse — large commits
  mixing unrelated changes

## Recommended focus
- TypeScript type system depth: generics and utility types — declared confidence (6)
  is lower than actual ceiling; this is the highest-leverage area right now
- PostgreSQL query performance: indexing strategy and reading EXPLAIN output —
  critical gap for production systems
- Security: input validation patterns and OWASP Top 10 applied to Node.js APIs —
  confidence (5) with no defensive habits observed in practice
- Testing: moving from after-the-fact coverage to test-first on business logic

## Open hypotheses
- Low testing confidence may stem from not having worked on a project with a strong
  TDD culture, rather than a conceptual gap — a well-framed lesson on test design
  (not just coverage) might shift the pattern quickly
- TypeScript `any` usage under pressure suggests the type system feels like friction
  rather than value — focus lessons on moments where types catch real bugs to
  reframe the mental model
